const BookComment = () => {
  return <></>;
};

export default BookComment;
