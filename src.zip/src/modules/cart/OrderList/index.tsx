import Home from "@/pages/Home";

const OrderList = () => {
  return (
    <>
      <h2>주문목록</h2>
    </>
  );
};

export default OrderList;
