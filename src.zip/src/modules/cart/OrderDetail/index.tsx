import Home from "@/pages/Home";

const OrderDetail = () => {
  return (
    <>
      <h2>주문상세</h2>
    </>
  );
};

export default OrderDetail;
